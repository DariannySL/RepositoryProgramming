﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio___Ado.NetSqlServer
{
    public class Paises
    {
        public int IdPais { get; set; }
        public string NombrePais { get; set; }
    }

    public class Sexo
    {
        public int IdSexo { get; set; }
        public string NombreSexo { get; set; }
    }

    public class Persona
    {
        public int IdPersona { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime FechaNac { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public int IdSexo { get; set; }
        public int Idpais { get; set; }
        public string Foto { get; set; }
    }
}
