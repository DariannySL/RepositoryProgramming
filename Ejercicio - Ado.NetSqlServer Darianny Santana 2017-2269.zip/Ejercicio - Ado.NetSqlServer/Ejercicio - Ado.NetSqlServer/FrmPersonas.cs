﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ejercicio___Ado.NetSqlServer
{
    public partial class FrmPersonas : Form
    {
        public FrmPersonas()
        {
            InitializeComponent();
        }

        SqlConnection Connection = new SqlConnection(Properties.Settings.Default.connection);
        SqlCommand Command = new SqlCommand();

        private void CargarPersonas(DataGridView Dgv)
        {
            SqlDataAdapter DataAdapter = new SqlDataAdapter("SELECT * FROM Persona WHERE Eliminado = 0", Connection);
            DataTable DataTable = new DataTable();
            DataAdapter.Fill(DataTable);
            Dgv.DataSource = DataTable;
        }

        private void FrmPersonas_Load(object sender, EventArgs e)
        {
            SqlCommand Command = new SqlCommand("SELECT * FROM Persona WHERE Eliminado = 0", Connection);
            SqlDataAdapter DataAdapter = new SqlDataAdapter();
            DataAdapter.SelectCommand = Command;
            DataTable DataTable = new DataTable();
            DataAdapter.Fill(DataTable);
            DgvPersona.DataSource = DataTable;

            DataTable Dt = new DataTable();

            CbPais.DataSource = SeleccionarPais();
            CbPais.DisplayMember = "NombrePais";
            CbPais.ValueMember = "IdPais";

            CbSexo.DataSource = SeleccionarSexo();
            CbSexo.DisplayMember = "NombreSexo";
            CbSexo.ValueMember = "IdSexo";
        }

        private static List<Paises> SeleccionarPais()
        {
            SqlCommand Command = null;
            SqlDataReader DataReader = null;
            List<Paises> ListaPais = new List<Paises>();
            SqlConnection Connection = new SqlConnection(Properties.Settings.Default.connection);

            Connection.Open();
            Command = Connection.CreateCommand();

            Command.CommandText = "SELECT * FROM Paises";
            DataReader = Command.ExecuteReader();

            while (DataReader.Read())
            {
                Paises Pais = new Paises();
                Pais.IdPais = (int)DataReader["IdPais"];
                Pais.NombrePais = (string)DataReader["NombrePais"];
                ListaPais.Add(Pais);
            }
            DataReader.Close();
            Connection.Close();

            return ListaPais;
        }

        private static List<Sexo> SeleccionarSexo()
        {
            SqlCommand Command = null;
            SqlDataReader DataReader = null;
            List<Sexo> ListaSexo = new List<Sexo>();
            SqlConnection Connection = new SqlConnection(Properties.Settings.Default.connection);

            Connection.Open();
            Command = Connection.CreateCommand();

            Command.CommandText = "SELECT * FROM Sexo";
            DataReader = Command.ExecuteReader();

            while (DataReader.Read())
            {
                Sexo Sexo = new Sexo();
                Sexo.IdSexo = (int)DataReader["IdSexo"];
                Sexo.NombreSexo = (string)DataReader["NombreSexo"];
                ListaSexo.Add(Sexo);
            }
            DataReader.Close();
            Connection.Close();

            return ListaSexo;
        }

        private void Limpiar()
        {
            foreach (var i in this.Controls)
            {
                if (i is TextBox)
                    ((TextBox)i).Text = "";
            }

            foreach (var i in this.Controls)
            {
                if (i is MaskedTextBox)
                    ((MaskedTextBox)i).Text = "";
            }

            foreach (var i in this.Controls)
            {
                if (i is ComboBox)
                    ((ComboBox)i).SelectedIndex = 0;
            }

            PbFoto.Image = null;
        }

        private void BtnFoto_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string Foto = openFileDialog1.FileName;
            PbFoto.ImageLocation = Foto;
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(MtbId.Text))
                {
                    if (string.IsNullOrWhiteSpace(TxtNombre.Text) | string.IsNullOrWhiteSpace(TxtApellido.Text))
                    {
                        MessageBox.Show("No se admiten campos vacios, favor de rellenar todos los campos", "Error");
                    }
                    else
                    {
                        string Query = "INSERT INTO Persona(Nombre, Apellido, FechaNacimiento, Telefono, Email, IdSexo, IdPais, Foto)" +
                                       "VALUES (@Nombre, @Apellido, @FechaNacimiento, @Telefono, @Email, @IdSexo, @IdPais, @Foto)";

                        Connection.Open();
                        SqlCommand Command = new SqlCommand(Query, Connection);

                        Command.Parameters.AddWithValue("@Nombre", TxtNombre.Text);
                        Command.Parameters.AddWithValue("@Apellido", TxtApellido.Text);
                        Command.Parameters.AddWithValue("@FechaNacimiento", DtpFechaNac.Value);
                        Command.Parameters.AddWithValue("@Telefono", MsbTelefono.Text);
                        Command.Parameters.AddWithValue("@Email", TxtEmail.Text);
                        Command.Parameters.AddWithValue("@IdSexo", CbSexo.SelectedValue.ToString());
                        Command.Parameters.AddWithValue("@IdPais", CbPais.SelectedValue.ToString());
                        Command.Parameters.AddWithValue("@Foto", PbFoto.ImageLocation);

                        Command.ExecuteNonQuery();
                        MessageBox.Show("Persona agregada con exito", "Agregar");
                        Limpiar();
                        CargarPersonas(DgvPersona);
                        Connection.Close();
                    }
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(TxtNombre.Text) | string.IsNullOrWhiteSpace(TxtApellido.Text))
                    {
                        MessageBox.Show("No se admiten campos vacios, favor de rellenar todos los campos", "Error");
                    }
                    else
                    {
                        SqlCommand Command = null;
                        Command = Connection.CreateCommand();
                        Connection.Open();

                        Command.CommandText = "UPDATE Persona SET [Nombre] = @Nombre, [Apellido] = @Apellido, [FechaNacimiento] = @FechaNacimiento, " +
                                           "[Telefono] = @Telefono, [Email] = @Email, [IdSexo] = @IdSexo, [IdPais] =  @IdPais, [Foto] = @Foto" +
                                           " WHERE [IdPersona] = @IdPersona";

                        Command.Parameters.AddWithValue("@IdPersona", MtbId.Text);
                        Command.Parameters.AddWithValue("@Nombre", TxtNombre.Text);
                        Command.Parameters.AddWithValue("@Apellido", TxtApellido.Text);
                        Command.Parameters.AddWithValue("@FechaNacimiento", DtpFechaNac.Value);
                        Command.Parameters.AddWithValue("@Telefono", MsbTelefono.Text);
                        Command.Parameters.AddWithValue("@Email", TxtEmail.Text);
                        Command.Parameters.AddWithValue("@IdSexo", CbSexo.SelectedValue.ToString());
                        Command.Parameters.AddWithValue("@IdPais", CbPais.SelectedValue.ToString());
                        Command.Parameters.AddWithValue("@Foto", PbFoto.ImageLocation);

                        Command.ExecuteNonQuery();
                        MessageBox.Show("Persona Actualizada con exito", "Actualizar");
                        Connection.Close();
                        Limpiar();
                        Connection.Close();
                        CargarPersonas(DgvPersona);
                    }
                }
            }catch (Exception Error)
            {
                MessageBox.Show("Se ha presentado un error. " + Error.Message, "Error");
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (DgvPersona.Rows.Count > 0)
            {
                try
                {
                    if (MessageBox.Show("Desea eliminar a esta persona?", "Eliminar", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        //string Query = "DELETE FROM Persona WHERE IdPersona = @IdPersona";
                        string Query = "Update Persona Set Eliminado = 1 WHERE IdPersona = @IdPersona";

                        Connection.Open();
                        SqlCommand Command = new SqlCommand(Query, Connection);

                        Command.Parameters.AddWithValue("@IdPersona", MtbId.Text);

                        Command.ExecuteNonQuery();
                        MessageBox.Show("Usuario eliminado");
                        Connection.Close();

                        Limpiar();
                        CargarPersonas(DgvPersona);
                    }
                }
                catch (Exception Error)
                {
                    MessageBox.Show("Se ha presentado un error. " + Error.Message, "Error");
                }
            }
        }

        private List<Persona> Consultar()
        {
            SqlDataReader DataReader = null;
            List<Persona> ListaPer = new List<Persona>();

            Connection.Open();
            Command = Connection.CreateCommand();

            string BuscarPer = TxtBuscar.Text;
            Command.CommandText = @"SELECT * FROM Persona WHERE Nombre = @Nombre";
            Command.Parameters.AddWithValue("@Nombre", BuscarPer);
            DataReader = Command.ExecuteReader();

            while (DataReader.Read())
            {
                Persona Persona = new Persona();
                Persona.IdPersona = (int)DataReader["IdPersona"];
                Persona.Nombre = (string)DataReader["Nombre"];
                Persona.Apellido = (string)DataReader["Apellido"];
                Persona.Email = (string)DataReader["Email"];
                Persona.FechaNac = (DateTime)DataReader["FechaNacimiento"];
                Persona.Foto = (string)DataReader["Foto"];
                Persona.Idpais = (int)DataReader["IdPais"];
                Persona.IdSexo = (int)DataReader["IdSexo"];
            }

            DataReader.Close();
            Connection.Close();
            return ListaPer;
        }


        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            DgvPersona.DataSource = Consultar();
        }

        private void DgvPersona_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                MtbId.Text = DgvPersona.CurrentRow.Cells[0].Value.ToString();
                TxtNombre.Text = DgvPersona.CurrentRow.Cells[1].Value.ToString();
                TxtApellido.Text = DgvPersona.CurrentRow.Cells[2].Value.ToString();
                DtpFechaNac.Value = Convert.ToDateTime(DgvPersona.CurrentRow.Cells[3].Value.ToString());
                TxtEmail.Text = DgvPersona.CurrentRow.Cells[5].Value.ToString();
                MsbTelefono.Text = DgvPersona.CurrentRow.Cells[4].Value.ToString();
                CbPais.Text = DgvPersona.CurrentRow.Cells[7].Value.ToString();
                CbSexo.Text = DgvPersona.CurrentRow.Cells[6].Value.ToString();
                PbFoto.ImageLocation = DgvPersona.CurrentRow.Cells[8].Value.ToString();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void BtnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }
    }
}
